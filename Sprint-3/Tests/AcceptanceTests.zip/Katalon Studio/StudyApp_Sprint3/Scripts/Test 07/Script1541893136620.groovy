import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('')

WebUI.navigateToUrl('https://warm-eyrie-11186.herokuapp.com/')

WebUI.setText(findTestObject('Object Repository/Notes/Page_Study App/input_Login_username'), 'new')

WebUI.setText(findTestObject('Object Repository/Notes/Page_Study App/input_Login_password'), 'user')

WebUI.click(findTestObject('Object Repository/Notes/Page_Study App/input_Login_btn btn-primary'))

WebUI.click(findTestObject('Object Repository/Notes/Page_StudyApp/a_Create note and save'))

WebUI.setText(findTestObject('Object Repository/Notes/Page_/input_Edit Note_title'), 'New title')

WebUI.click(findTestObject('Object Repository/Notes/Page_/iframe_Table_mytextarea_ifr'))

WebUI.setText(findTestObject('Object Repository/Notes/Page_/body_hello'), 'Hello! I am adding new notes!')

WebUI.click(findTestObject('Object Repository/Notes/Page_/input_tinymce_donebtn'))

WebUI.click(findTestObject('Object Repository/Notes/Page_StudyApp/a_New title'))

WebUI.verifyElementText(findTestObject('Object Repository/Notes/Page_/body_hello'), 'Hello! I am adding new notes!')

WebUI.click(findTestObject('Object Repository/Flashcards/Page_/button_Delete Flashcard'))

WebUI.closeBrowser()
