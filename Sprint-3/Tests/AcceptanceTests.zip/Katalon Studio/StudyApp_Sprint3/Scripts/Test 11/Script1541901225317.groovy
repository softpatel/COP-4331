import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS


WebUI.openBrowser('')

WebUI.navigateToUrl('https://warm-eyrie-11186.herokuapp.com/')

WebUI.setText(findTestObject('Object Repository/Timer/Page_Study App/input_Login_username'), 'new')

WebUI.setText(findTestObject('Object Repository/Timer/Page_Study App/input_Login_password'), 'user')

WebUI.click(findTestObject('Object Repository/Timer/Page_Study App/input_Login_btn btn-primary'))

WebUI.click(findTestObject('Object Repository/Timer/Page_StudyApp/a_SD'))

WebUI.scrollToPosition(9999999, 9999999)

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_Pomodoro Timer'))

WebUI.scrollToPosition(9999999, 9999999)

WebUI.waitForElementClickable(findTestObject('Object Repository/Timer/Page_/button_Pie Chart'), 4)

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_Pie Chart'))

WebUI.scrollToPosition(9999999, 9999999)

WebUI.verifyElementPresent(findTestObject('Object Repository/Timer/Page_/div_No time recorded'), 0)

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_Pie Chart'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_- (1)'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_-_1'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_-_1'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_-_1'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_-_1'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_StartPause'))

WebUI.delay(70)

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_Stop'))

WebUI.click(findTestObject('Object Repository/Timer/Page_/button_Pie Chart'))

WebUI.scrollToPosition(9999999, 9999999)

WebUI.verifyElementPresent(findTestObject('Object Repository/Timer/Page_/div_Study ProgressStudy (Minut'), 0)

WebUI.scrollToPosition(9999999, 9999999)

WebUI.waitForElementVisible(findTestObject('Object Repository/Timer/Page_/div_Total Study Time 1.00 Minu'), 4)

WebUI.verifyElementPresent(findTestObject('Object Repository/Timer/Page_/div_Total Study Time 1.00 Minu'), 4)

WebUI.verifyElementPresent(findTestObject('Object Repository/Timer/Page_/div_Total Break Time 0.18 Minu'), 4)

WebUI.closeBrowser()
