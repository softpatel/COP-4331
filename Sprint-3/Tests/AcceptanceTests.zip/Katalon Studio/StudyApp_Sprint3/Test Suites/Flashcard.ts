<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Tests all functionalities of flashcard</description>
   <name>Flashcard</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-11-11T01:41:27</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>cf4027c8-3f80-4fa2-a605-6f1a6490017f</testSuiteGuid>
   <testCaseLink>
      <guid>5953f89d-936b-4da4-a748-4b7e88564cad</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 01</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>efdd52ec-8491-4ed6-a879-7f23ff245a26</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 02</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bfc7529e-a4e4-433f-9581-4a03470d3e43</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 13</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
