<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Test all functionalities of note</description>
   <name>Notes</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-11-11T01:11:30</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>93665dbd-777f-4781-9ed8-ebf128258cb8</testSuiteGuid>
   <testCaseLink>
      <guid>11f8a57e-4e10-4dbf-bbec-e0bc784f7f61</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 03</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>b934f510-ee39-475d-89bb-f8a7593402c5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 06</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>e43df551-85bb-43e9-8a5f-d5342d8c26d6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 07</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
