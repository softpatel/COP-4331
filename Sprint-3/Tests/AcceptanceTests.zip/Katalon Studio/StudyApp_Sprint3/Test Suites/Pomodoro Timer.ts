<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Test all functionalities of the timer.</description>
   <name>Pomodoro Timer</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-11-11T01:18:22</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>3a8f4063-0911-486b-9db5-8241a6a866ed</testSuiteGuid>
   <testCaseLink>
      <guid>d4c4bc14-c1f6-4b89-ab4d-c425bc8f0ce4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 08</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c173f49a-f965-414c-b747-93675cf3532a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 09</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>cb76756a-d0b4-469f-9543-5b35751e6302</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 10</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>f58748e1-7e91-46da-82d7-690081b2d070</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 11</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
