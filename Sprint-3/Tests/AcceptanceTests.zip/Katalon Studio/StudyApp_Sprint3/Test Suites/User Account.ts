<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description>Test all functionalities of the user account.
**** This suite should only be run once! Running more than once will lead to failure of test 04 ****</description>
   <name>User Account</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <lastRun>2018-11-11T01:14:05</lastRun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <testSuiteGuid>0c8156e6-4d0e-4c69-bea1-8461fd1df15d</testSuiteGuid>
   <testCaseLink>
      <guid>cb621531-3ce8-47d6-aeed-611976a69343</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 04</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8aef8460-6c04-444c-86f7-3ed2c4c4822e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 05</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d902994c-0365-4337-a210-f8d872a947eb</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Test 12</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
